# DT25 Stage 6 RFM Execution Package

## Mục đích

Package tạo bảng RFM liên tục, điểm RFM mô tả, cờ ngoại lai cấp khách hàng và ba phương án preprocessing từ file đã nghiệm thu `online_retail_rfm_eligible.csv`. Package không chạy K-Means và không chọn phương án preprocessing cuối.

## Cách chạy trên Google Colab

1. Tải và giải nén `DT25_Stage6_RFM_Execution_Package.zip`.
2. Mở `DT25_Stage6_RFM_Execution.ipynb` bằng Google Colab.
3. Chọn **Runtime > Run all**.
4. Ở Cell 3, upload đúng file `online_retail_rfm_eligible.csv` từ evidence Giai đoạn 4.
5. Notebook chỉ sao chép file vào project sau khi xác minh tên, định dạng CSV, schema, 392.692 dòng và 4.338 CustomerID duy nhất.
6. Không sửa số liệu, baseline, test hoặc Acceptance Summary.
7. Cell 19 sẽ tạo và tải `DT25_Stage6_RFM_Evidence.zip` nếu toàn bộ kiểm tra đạt.

## Reference date

Notebook tính `REFERENCE_DATE = MAX(InvoiceDate) + 1 ngày`. Quy tắc này đặt mốc ngay sau lần giao dịch cuối của dữ liệu lịch sử, không phụ thuộc ngày chạy hiện tại và bảo đảm mọi Recency không âm.

## Output chính

- `data/processed/rfm_customers.csv`
- `data/processed/rfm_with_scores.csv`
- `data/processed/rfm_standard_raw.csv`
- `data/processed/rfm_log_standard.csv`
- `data/processed/rfm_robust_raw.csv`
- Bảng audit tại `outputs/tables/rfm/`
- Ba biểu đồ tại `outputs/figures/rfm/`
- Evidence ZIP tại project root

## Bằng chứng gửi lại cho chat

Ưu tiên gửi `DT25_Stage6_RFM_Evidence.zip`. Nếu giao diện không nhận ZIP, xuất evidence sang TXT theo cùng cách Giai đoạn 4, tối thiểu gồm:

- `acceptance_summary.txt`
- `execution_log.txt`
- `input_checksum_report.txt` và CSV
- `output_verification.csv`
- `rfm_acceptance_matrix.csv`
- `rfm_manual_validation.csv`
- `rfm_distribution_summary.csv`
- `rfm_outlier_summary.csv`
- `rfm_score_distribution.csv`
- `rfm_preprocessing_comparison.csv`
- `pytest_output.txt`
- source module và test
- manifest, SHA-256 register, kích thước và line count của CSV lớn

## Khi có lỗi

- Không sửa Acceptance Summary bằng tay.
- Không xóa assertion, nới baseline hoặc tạo dữ liệu mẫu.
- Giữ traceback và execution log.
- Chỉ sửa lỗi kỹ thuật tối thiểu, sau đó restart runtime và Run all từ đầu.
- Không sử dụng output của lần chạy lỗi để nghiệm thu.
